import React, { useEffect, useState } from 'react';
import './recommendationImages.css';

function RecommendationImages({ emojis }) {
    const [visibleEmojis, setVisibleEmojis] = useState([]);

    useEffect(() => {
        // Clear visible emojis when new emojis are received
        setVisibleEmojis([]);
        let timeoutIds = [];
        emojis.forEach((emoji, index) => {
            const timeoutId = setTimeout(() => {
                setVisibleEmojis((prev) => [...prev, emoji]);
            }, index * 200);
            timeoutIds.push(timeoutId);
        });

        return () => {
            timeoutIds.forEach(clearTimeout);
        };
    }, [emojis]);

    return (
        <div className='emoji-container'>
            {visibleEmojis.map((emoji, index) => (
                <div key={index} className='emoji popup'>
                    <img className='emoji-img' src={emoji.image} alt={emoji.label} title={emoji.label}/>
                </div>
            ))}
        </div>
    );
}

export default RecommendationImages;