import './Dashboard.css';
import {RangeGaugeComponent} from "@/components/features/rangeGauge/rangeGauge.jsx";
import ForecastChart from "@/components/features/forecastChart/forecastChart.jsx";
import {Autocomplete, TextField} from "@mui/material";
import {useState} from "react";
import outdoor from "../../assets/emojis/outdoor.png";
import sunscreen from "../../assets/emojis/sunscreen.png";
import sunglasses from "../../assets/emojis/sunglasses.png";
import hats from "../../assets/emojis/hats.png";
import umbrella from "../../assets/emojis/umbrella.png";
import thermometer from "../../assets/emojis/thermometer.png";
import clothes from "../../assets/emojis/clothes.png";
import tree from "../../assets/emojis/tree.png";
import house from "../../assets/emojis/house.png";
import drink from "../../assets/emojis/drink.png";
import mask from "../../assets/emojis/mask.png";
import tissues from "../../assets/emojis/tissues.png";
import meds from "../../assets/emojis/meds.png";
import changeClothes from "../../assets/emojis/change-clothes.png";
import shower from "../../assets/emojis/shower.png";
import windows from "../../assets/emojis/windows.png";
import wiping from "../../assets/emojis/wiping.png";
import airPurifier from "../../assets/emojis/air-purifier.png";
import vacuum from "../../assets/emojis/vacuum.png";
import laundry from "../../assets/emojis/laundry.png";
import RecommendationImages from "@/components/features/recommendationImages/recommendationImages.jsx";
import {CustomSegmentLabelPosition} from "react-d3-speedometer";

const pollenApiResponse = {
    regionCode: "IL",
    dailyInfo: [
        {
            date: {year: 2023, month: 7, day: 11},
            pollenValue: 1
        },
        {
            date: {year: 2023, month: 7, day: 12},
            pollenValue: 4
        },
        {
            date: {year: 2023, month: 7, day: 13},
            pollenValue: 3
        },
        {
            date: {year: 2023, month: 7, day: 14},
            pollenValue: 2
        },
        {
            date: {year: 2023, month: 7, day: 15},
            pollenValue: 5
        },
    ],
};

const pollenForecastLineColor = "#4cca79";

const uvApiResponse = {
    regionCode: "IL",
    dailyInfo: [
        {
            date: {year: 2023, month: 7, day: 11},
            uvIndex: 1
        },
        {
            date: {year: 2023, month: 7, day: 12},
            uvIndex: 8
        },
        {
            date: {year: 2023, month: 7, day: 13},
            uvIndex: 10
        },
        {
            date: {year: 2023, month: 7, day: 14},
            uvIndex: 3
        },
        {
            date: {year: 2023, month: 7, day: 15},
            uvIndex: 2
        },
        // Add more dailyInfo objects here...
    ],
};

const uvForecastLineColor = "#ff7300";

const uvRangeColors = ["#1C9D31", "#68BE4C", "#FCBD24", "#F56B33", "#eb184a"];

const pollenRangeColors = ["#DADADA", "#1C9D31", "#43B447", "#FAFF00", "#FC9200", "#F33600"];

const suburbs = [
    {label: 'Carlton'},
    {label: 'Clayton'},
    {label: 'Glen Huntly'},
    {label: 'Caulfield'},
    {label: 'Carrum'},
    {label: 'Aspendale'},
    {label: 'Hawthorn'},
];

const uvDataEmojiMap = {
    'outdoor': {image: outdoor, label: 'Good time for outdoor activities.'},
    'sunscreen-30': {image: sunscreen, label: 'Use SPF 30 sunscreen.'},
    'sunscreen-50': {image: sunscreen, label: 'Use SPF 50 sunscreen.'},
    'sunglasses': {image: sunglasses, label: 'Wear sunglasses.'},
    'hats': {image: hats, label: 'Wear a hat.'},
    'umbrella': {image: umbrella, label: 'Carry an umbrella.'},
    'thermometer': {image: thermometer, label: 'Stay hydrated during excessive heat.'},
    'clothes': {image: clothes, label: 'Wear light clothes.'},
    'tree': {image: tree, label: 'Stay in the shade.'},
    'house': {image: house, label: 'Stay indoors.'}
};

const pollenDataEmojiMap = {
    'drink': {image: drink, label: 'Stay hydrated.'},
    'mask': {image: mask, label: 'Wear a mask.'},
    'tissues': {image: tissues, label: 'Carry tissues.'},
    'meds': {image: meds, label: 'Take your medication.'},
    'change-clothes': {image: changeClothes, label: 'Change clothes after coming indoors.'},
    'shower': {image: shower, label: 'Take a shower.'},
    'windows': {image: windows, label: 'Keep windows closed.'},
    'wiping': {image: wiping, label: 'Wipe surfaces.'},
    'indoor': {image: house, label: 'Stay indoors.'},
    'air-purifier': {image: airPurifier, label: 'Use an air purifier.'},
    'vacuum': {image: vacuum, label: 'Vacuum regularly.'},
    'laundry': {image: laundry, label: 'Do laundry.'},
    'sunscreen': {image: sunscreen, label: 'Use sunscreen.'},
    'outdoor': {image: outdoor, label: 'Good time for outdoor activities.'}
};

const uvSegmentLabels = [
    {text: "Low", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "Moderate", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "High", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "Very High", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "Extreme", color: "black", position: CustomSegmentLabelPosition.Outside}
];

const pollenSegmentLabels = [
    {text: "None", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "Very Low", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "Low", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "Moderate", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "High", color: "black", position: CustomSegmentLabelPosition.Outside},
    {text: "Very High", color: "black", position: CustomSegmentLabelPosition.Outside}
];

function Dashboard() {

    const [selectedCity, setSelectedCity] = useState('');
    const [uvIndexData, setUvIndexData] = useState(1);
    const [pollenData, setPollenData] = useState(0);
    const [uvDataEmoji, setUvDataEmoji] = useState([]);
    const [pollenDataEmoji, setPollenDataEmoji] = useState([]);
    const [uvForecastData, setUvForecastData] = useState({});
    const [pollenForecastData, setPollenForecastData] = useState({});

    // TODO: fetch from API?
    function getUVForecastData(suburb) {
        return uvApiResponse;
    }

    // TODO: fetch from API?
    function getPollenForecastData(suburb) {
        return pollenApiResponse;
    }

    const onCityChange = (newValue) => {
        if (newValue) {
            setSelectedCity(newValue);
            // Fetch data for the selected suburb
            // Update the state with the fetched data
            const uvData = getUVIndexData(newValue.label);
            setUvIndexData(uvData.value);
            const pollenData = getPollenData(newValue.label);
            setPollenData(pollenData.value);
            setUvDataEmoji(uvData.emojis);
            setPollenDataEmoji(pollenData.emojis);
            setUvForecastData(getUVForecastData(newValue.label));
            setPollenForecastData(getPollenForecastData(newValue.label));
            console.log("Selected city:", newValue, "UV data:", uvData, "Pollen data:", pollenData);
        }
    }

    // TODO: fetch from API?
    function getUVIndexData(suburb) {
        // Fetch UV index data for the selected suburb
        // return no between 1 and 11 and also set of emojis as list
        const uvIndex = Math.floor(Math.random() * 11) + 1;
        const uvEmojis = getUVEmoji(uvIndex);
        return {value: uvIndex, emojis: uvEmojis};
    }

    // TODO: fetch from API?
    function getPollenData(suburb) {
        // Fetch pollen data for the selected suburb
        // return no between 1 and 5
        const pollenData = Math.floor(Math.random() * 5) + 1;
        const pollenEmojis = getPollenEmoji(pollenData);
        return {value: pollenData, emojis: pollenEmojis};
    }

    function getUVEmoji(value) {
        const emojis = []
        if (value >= 1 && value <= 2) {
            emojis.push(uvDataEmojiMap.outdoor);
        } else if (value >= 3 && value <= 5) {
            emojis.push(uvDataEmojiMap['sunscreen-30']);
            emojis.push(uvDataEmojiMap.hats);
            emojis.push(uvDataEmojiMap.umbrella);
        } else if (value >= 6 && value <= 7) {
            emojis.push(uvDataEmojiMap['sunscreen-30']);
            emojis.push(uvDataEmojiMap.hats);
            emojis.push(uvDataEmojiMap.sunglasses);
            emojis.push(uvDataEmojiMap.clothes);
            emojis.push(uvDataEmojiMap.umbrella);
            emojis.push(uvDataEmojiMap.thermometer);
            emojis.push(uvDataEmojiMap.tree);
        } else if (value >= 8 && value <= 10) {
            emojis.push(uvDataEmojiMap['sunscreen-50']);
            emojis.push(uvDataEmojiMap.hats);
            emojis.push(uvDataEmojiMap.clothes);
            emojis.push(uvDataEmojiMap.sunglasses);
            emojis.push(uvDataEmojiMap.tree);
            emojis.push(uvDataEmojiMap.house);
        } else if (value >= 11) {
            emojis.push(uvDataEmojiMap.house);
        }
        return emojis;
    }

    function getPollenEmoji(value) {
        const emojis = []
        if (value === 0) {
            emojis.push(pollenDataEmojiMap.outdoor);
            emojis.push(pollenDataEmojiMap.drink);
            emojis.push(pollenDataEmojiMap.sunscreen);
        } else if (value === 1) {
            emojis.push(pollenDataEmojiMap.outdoor);
            emojis.push(pollenDataEmojiMap.windows);
        } else if (value === 2) {
            emojis.push(pollenDataEmojiMap.outdoor);
            emojis.push(pollenDataEmojiMap.windows);
            emojis.push(pollenDataEmojiMap.wiping);
        } else if (value === 3) {
            emojis.push(pollenDataEmojiMap.tissues);
            emojis.push(pollenDataEmojiMap.mask);
            emojis.push(pollenDataEmojiMap.indoor);
        } else if (value === 4) {
            emojis.push(pollenDataEmojiMap['change-clothes']);
            emojis.push(pollenDataEmojiMap.shower);
            emojis.push(pollenDataEmojiMap.meds);
            emojis.push(pollenDataEmojiMap.tissues);
            emojis.push(pollenDataEmojiMap.mask);
            emojis.push(pollenDataEmojiMap.indoor);
        } else if (value === 5) {
            emojis.push(pollenDataEmojiMap["air-purifier"]);
            emojis.push(pollenDataEmojiMap.laundry);
            emojis.push(pollenDataEmojiMap.vacuum);
        }
        return emojis;
    }

    return (
        <div className='dashboard'>
            <Autocomplete
                disablePortal
                options={suburbs}
                value={selectedCity}
                onChange={(event, newValue) => {
                    onCityChange(newValue);
                }}
                sx={{width: 300}}
                renderInput={(params) =>
                    <TextField {...params} label={selectedCity ? selectedCity.value : 'Enter suburb...'}/>}
            />
            <div className='row-container'>
                <div className='left-container'>
                    <RangeGaugeComponent
                        value={uvIndexData}
                        minValue={1}
                        maxValue={11}
                        currentValueText={uvIndexData > 1 ? "UV Level - " + uvIndexData : "UV Level"}
                        segments={5}
                        segmentColors={uvRangeColors}
                        customSegmentLabels={uvSegmentLabels}
                    />
                    <RecommendationImages emojis={uvDataEmoji}/>

                    <RangeGaugeComponent
                        value={pollenData}
                        minValue={0}
                        maxValue={6}
                        currentValueText={pollenData ? "Pollen Level - " + pollenData : "Pollen Level"}
                        segments={6}
                        segmentColors={pollenRangeColors}
                        customSegmentLabels={pollenSegmentLabels}
                    />
                    <RecommendationImages emojis={pollenDataEmoji}/>
                </div>
                <div className='right-container'>
                    <ForecastChart
                        apiResponse={uvForecastData}
                        forecastType="uvIndex"
                        chartTitle="5-Day UV Exposure Forecast"
                        lineColor={uvForecastLineColor}
                    />

                    <ForecastChart
                        apiResponse={pollenForecastData}
                        forecastType="pollenValue"
                        chartTitle="5-Day Pollen Forecast"
                        lineColor={pollenForecastLineColor}
                    />

                </div>
            </div>
        </div>
    );
}

export default Dashboard;